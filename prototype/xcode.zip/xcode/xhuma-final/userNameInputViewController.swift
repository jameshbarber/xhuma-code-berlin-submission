//
//  ViewController.swift
//  xhuma-final
//
//  Created by James Hilton-Barber on 2019/07/31.
//  Copyright © 2019 James Hilton-Barber. All rights reserved.
//

import UIKit

class userNameInputViewController: UIViewController {
    
    @IBOutlet weak var usernameTxtField: UITextField!
    
    
    @IBAction func continueOn(_ sender: Any) {
        // Save user info to UserDefaults for permenance
        UserDefaults.standard.set(UITextField.text, forKey: "device-id")
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    
}

