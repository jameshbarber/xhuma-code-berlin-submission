//
//  ViewController.swift
//  xhuma-final
//
//  Created by James Hilton-Barber on 2019/07/31.
//  Copyright © 2019 James Hilton-Barber. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // storyboard links
    @IBOutlet weak var networkImage: UIImageView!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var notConnected1: UILabel!
    @IBOutlet weak var notConnected2: UILabel!
    
    var state = "connected"
    var states = ["connected", "connecting", "disconnected"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        notConnected1.isHidden = true
        notConnected2.isHidden = true
        
        updateInterface(state: state)
        
    }
    
    @IBAction func toggleState(_ sender: Any) {
        state = states[states.firstIndex(of: state)!+1]
        updateInterface(state: state)
    }
    
    
    func updateInterface(state: String){
        
        switch state {
        case "connected":
            networkImage.image = UIImage(named: "mesh_active.png")
            statusLabel.text = "Connected to Xhuma"
            notConnected1.isHidden = true
            notConnected2.isHidden = true
        case "connecting":
            networkImage.image = UIImage(named: "mesh_inactive.png")
            statusLabel.text = "Connecting to Xhuma..."
        default:
            statusLabel.text = "No Connection To Network"
            networkImage.image = UIImage(named: "mesh_inactive.png")
            notConnected1.isHidden = false
            notConnected2.isHidden = false
            
            
        }
        
    }


}

